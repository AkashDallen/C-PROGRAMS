#include <stdio.h>

const int CITY=2;
const int WEEK=7;
void main()
{
   int temperature[CITY][WEEK];
   int i ,j;

   for(i=0;i<CITY;i++)
   {
       for(j=0;j<WEEK;j++)
       {
           printf("City[%d], Day[%d]: ", i+1, j+1);
           scanf("%d", &temperature[i][j] );
       }
       printf("\n");
   }

int min,max,k,day;
   for(k=0;k<CITY;k++)
   {
       max = temperature[k][0];
       for(j=0;j<WEEK;j++)
       {
            if(temperature[k][j] > max)
            {
                max = temperature[k][j];
                day=j+1;
            }
        }
        printf("highest temperature of City%d is %d on day %d\n",k+1,max,day);
        min = temperature[k][0];
        for(j=0;j<WEEK;j++)
        {
            if(temperature[k][j] < min)
                min = temperature[k][j];
        }
        printf("minimum temperature of City[%d]: %d\n",k+1,min);
   }
}