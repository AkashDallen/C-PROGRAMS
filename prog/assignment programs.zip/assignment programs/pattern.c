#include <stdio.h>
void main()
{
    printf("1\t\t  1\n");
    printf("1,2\t\t2,1\n");
    printf("1,2,3\t      3,2,1\n");
    printf("1,2,3,4     4,3,2,1\n");
    printf("1,2,3,4,5,5,4,3,2,1\n");
}